fancyBox - Changelog
=========

### Version 2.0.3 - November 29, 2011

* Fixed #29 - broken elastic transitions

### Version 2.0.2 - November 28, 2011

* Fixed slidshow
* Fixed scrollbar issue when displayed a very tall image
* New option "nextClick" - navigate to next gallery item when user clicks the content
* New option "modal" - to disable navigation and closing
* Add 'metadata' plugin support
* Add ability to create groups using 'data-fancybox-group' attribute
* Updated manual usage to match earlier releases


### Version 2.0.1 - November 23, 2011

* Fixed keyboard events inside form elements
* Fixed manual usage


### Version 2.0.0 - November 21, 2011

First release - completely rewritten, many new features and updated graphics.