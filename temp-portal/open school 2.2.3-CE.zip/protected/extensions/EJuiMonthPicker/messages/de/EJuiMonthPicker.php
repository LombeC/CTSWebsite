<?php
return array(
'January'=>'Jänner',
'February'=>'Februar',
'March'=>'März',
'May'=>'Mai',
'June'=>'Juni',
'July'=>'Juli',
'October'=>'Oktober',
'December'=>'Dezember',
'Oct'=>'Okt',
'Dec'=>'Dez',
'Select Month'=>'Monat Auswählen',
'Prev'=>'Vorheriger',
'Next'=>'Nächster',
);
?>