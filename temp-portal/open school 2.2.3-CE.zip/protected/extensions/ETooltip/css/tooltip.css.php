<?php
return ".tooltip {
        display:none;
        background:transparent url(".$image.");
        font-size:12px;
        height:70px;
        width:160px;
        padding:25px;
        color:#fff; 
}";
