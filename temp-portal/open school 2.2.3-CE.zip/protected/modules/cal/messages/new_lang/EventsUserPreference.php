<?php
return array(
    'Preference'=>'',
    'Mobile'=>'',
    'Mobile Alert'=>'',
    'Email'=>'',
    'Email Alert'=>'',
);
?>
