<?php
return array(
    'Preference'=>'Налаштування',
    'Mobile'=>'Номер мобільного',
    'Mobile Alert'=>'Повідомляти на мобільний',
    'Email'=>'Електронна пошта',
    'Email Alert'=>'Повідомляти на ел.пошту',
);
?>
